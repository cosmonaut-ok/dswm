#!/bin/sh

PTH=$(dirname $0)

cd $PTH
sh autogen.sh

